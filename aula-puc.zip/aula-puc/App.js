import React from 'react';
import {View, Text} from 'react-native';
import HomePage from './src/homePage'



const App = () => {

return(

<HomePage/>

);

}


export default App;
