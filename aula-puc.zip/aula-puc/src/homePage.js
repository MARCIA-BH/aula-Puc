import React from 'react';
import {View, Text} from 'react-native';

const HomePage = () => {

return(
<view>

<text> PUC MINAS </text>


</view>

);

}


export default HomePage;